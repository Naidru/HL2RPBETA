ITEM.name = "IMI Uzi 1950"
ITEM.description = "1950's SMG, alot of which are still found hidden around City-17 formerly known as New York..  to this day.. Highly illegal, but easy to conceal."
ITEM.model = "models/weapons/arccw/c_ud_uzi.mdl"
ITEM.class = "arccw_ud_uzi"
ITEM.weaponCategory = "sidearm"
ITEM.flag = "V"
ITEM.width = 2
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}