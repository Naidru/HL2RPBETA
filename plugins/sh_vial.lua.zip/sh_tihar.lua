ITEM.name = "Crude Pneumatic Rifle"
ITEM.description = "Powerful, unconventional take on a stealth sniper. Surprisingly deadly at the pressures it's rated to."
ITEM.model = "models/weapons/arccw_go/v_rif_aug.mdl"
ITEM.class = "arccw_go_aug"
ITEM.weaponCategory = "primary"
ITEM.flag = "V"
ITEM.width = 4
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}