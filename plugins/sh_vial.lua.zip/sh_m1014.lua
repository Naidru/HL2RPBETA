ITEM.name = "XM1014"
ITEM.description = "Terrifying gas-cyclic shotgun that is used exclusively by Conscripts in the Wasteland."
ITEM.model = "models/weapons/arccw/c_ud_m1014.mdl"
ITEM.class = "arccw_ud_m1014"
ITEM.weaponCategory = "primary"
ITEM.flag = "V"
ITEM.width = 4
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}