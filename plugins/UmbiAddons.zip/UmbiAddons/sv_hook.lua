local PLUGIN = PLUGIN

function PLUGIN:LoadData()
    print("If you see this, that means Umbree's items have loaded hopefully.")
end