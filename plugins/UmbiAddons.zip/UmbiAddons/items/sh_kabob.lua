ITEM.name = "Headcrab Skewer"
ITEM.RestoreHunger = 50
ITEM.model = "models/willardnetworks/food/meatskewer.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "Headcrab meat cooked and then stuck onto a skewer. Sold by street peddlers or made by Conscripts and Rebels when out in the field."
ITEM.category = "Consumables"
ITEM.permit = "consumables"

ITEM.functions.Eat = {
    OnRun = function(itemTable)
        local client = itemTable.player

        client:SetHealth(math.min(client:Health() + 10, 100))

        return true
    end,
} 