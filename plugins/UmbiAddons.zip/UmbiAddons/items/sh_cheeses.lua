ITEM.name = "Synthesized Cheese Slice"
ITEM.RestoreHunger = 50
ITEM.model = "models/willardnetworks/food/cheesewheel1c.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A slice off of a larger wheel of synthesized cheese. Even though there tends to be plenty of this stuff to go around, it doesn't stop one from dreaming of the real thing now and then. Just looking at it makes you sad."
ITEM.category = "Consumables"
ITEM.permit = "consumables"

ITEM.functions.Eat = {
    OnRun = function(itemTable)
        local client = itemTable.player

        client:SetHealth(math.min(client:Health() + 10, 100))

        return true
    end,
} 