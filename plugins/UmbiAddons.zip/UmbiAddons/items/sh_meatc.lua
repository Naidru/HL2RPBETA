ITEM.name = "Cooked Chunk of Meat"
ITEM.RestoreHunger = 50
ITEM.model = "models/willardnetworks/food/meat4.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "Try not to dwell on it."
ITEM.category = "Consumables"
ITEM.permit = "consumables"

ITEM.functions.Eat = {
    OnRun = function(itemTable)
        local client = itemTable.player

        client:SetHealth(math.min(client:Health() + 10, 100))

        return true
    end,
} 