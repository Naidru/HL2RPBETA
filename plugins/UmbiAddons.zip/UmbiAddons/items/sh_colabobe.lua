ITEM.name = "Radio Bob Energy"
ITEM.RestoreHunger = 50
ITEM.model = "models/willardnetworks/food/bobdrinks_premium.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "An off-shoot of the strange Radio Bob drinks that keep appearing around the city. It claims it's an energy drink, but the Union say it's an illegal substance."
ITEM.category = "Consumables"
ITEM.permit = "consumables"

ITEM.functions.Eat = {
    OnRun = function(itemTable)
        local client = itemTable.player

        client:SetHealth(math.min(client:Health() + 10, 100))

        return true
    end,
} 