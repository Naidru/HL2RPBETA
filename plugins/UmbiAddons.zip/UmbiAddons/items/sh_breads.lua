ITEM.name = "Sliced Bread"
ITEM.RestoreHunger = 50
ITEM.model = "models/willardnetworks/food/bread_slice.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "Nothing's been better than sliced bread since the Combine showed up. But it's still made of the same old synthesized crap, so maybe not."
ITEM.category = "Consumables"
ITEM.permit = "consumables"

ITEM.functions.Eat = {
    OnRun = function(itemTable)
        local client = itemTable.player

        client:SetHealth(math.min(client:Health() + 10, 100))

        return true
    end,
} 