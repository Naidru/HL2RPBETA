ITEM.name = "H&K UMP-45"
ITEM.description = "Slow firing, powerful SMG Favoured by the Resistance and MPF alike, not so nice on maintenance though."
ITEM.model = "models/weapons/arccw_go/v_smg_ump45.mdl"
ITEM.class = "arccw_go_ump"
ITEM.weaponCategory = "primary"
ITEM.flag = "V"
ITEM.width = 2
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}