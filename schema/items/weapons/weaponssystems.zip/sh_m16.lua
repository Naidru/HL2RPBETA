ITEM.name = "M16 Rifle"
ITEM.description = "An old, worn M16 rifle from the forgotten country known formerly as America."
ITEM.model = "models/weapons/arccw/c_ud_m16.mdl"
ITEM.class = "arccw_ud_m16"
ITEM.weaponCategory = "primary"
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}