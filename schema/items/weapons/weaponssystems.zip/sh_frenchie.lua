ITEM.name = "FN FAMAS G1"
ITEM.description = "Ugh.. Argh.. French."
ITEM.model = "models/weapons/arccw_go/v_rif_famas.mdl"
ITEM.class = "arccw_go_famas"
ITEM.weaponCategory = "primary"
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}