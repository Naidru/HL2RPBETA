ITEM.name = "AR-1"
ITEM.description = "Well maintained post-soviet era rifle, chambered in a rare round. Usually associated with the resistance."
ITEM.model = "models/weapons/w_rif_ak47.mdl"
ITEM.class = "arccw_hl_akm"
ITEM.weaponCategory = "primary"
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}