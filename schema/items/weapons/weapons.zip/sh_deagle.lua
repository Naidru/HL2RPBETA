ITEM.name = "HECU Desert Eagle"
ITEM.description = "Exceptionally rare, and powerful handgun, used by medics and engineers during the Black Mesa Incident and the Portal Storms. now it's yours."
ITEM.model = "models/weapons/arccw/c_ud_deagle.mdl"
ITEM.class = "arccw_ur_deagle"
ITEM.weaponCategory = "sidearm"
ITEM.flag = "V"
ITEM.width = 2
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}