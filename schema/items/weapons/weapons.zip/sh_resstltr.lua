ITEM.name = "Resistance Spec-Ops Rifle"
ITEM.description = "Strange highly compact rifle hailing from somewhere in the Slavic side of the Union, looks old and used up. Rusty but Trusty."
ITEM.model = "models/weapons/c_vsv.mdl"
ITEM.class = "arccw_vsv"
ITEM.weaponCategory = "primary"
ITEM.flag = "V"
ITEM.width = 2
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}