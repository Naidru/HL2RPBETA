ITEM.name = "M1911"
ITEM.description = "Classic US firearm, used in just about every war from the first world war till the 7 hour war. Beloved by most, and sought after by Rebels, Conscripts and CPS alike."
ITEM.model = "models/weapons/arccw/c_ur_m1911.mdl"
ITEM.class = "arccw_ur_m1911"
ITEM.weaponCategory = "sidearm"
ITEM.flag = "V"
ITEM.width = 1
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}