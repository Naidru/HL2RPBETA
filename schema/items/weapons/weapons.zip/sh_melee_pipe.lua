ITEM.name = "Lead Pipe"
ITEM.description = "As heavy as a sledgehammer, this pipe is a hefty weapon and the go-to choice for scavengers and people looking to defend their loot."
ITEM.model = "models/props_canal/mattpipe.mdl"
ITEM.class = "weapon_hl2pipe"
ITEM.weaponCategory = "melee"
ITEM.flag = "V"
ITEM.width = 1
ITEM.height = 3
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}