ITEM.name = "Stainless Pot"
ITEM.description = "It's said that this is a favourite weapon of the former Italian Mafia here in new york.. Whos' to say? "
ITEM.model = "models/props_junk/garbage_glassbottle003a.mdl"
ITEM.class = "weapon_hl2pot"
ITEM.weaponCategory = "melee"
ITEM.flag = "V"
ITEM.width = 1
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}