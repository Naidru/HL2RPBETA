ITEM.name = "Handmade Rifle"
ITEM.description = "Unusual but scary automatic assault rifle developed by an unknown gunsmith who then sold the blueprints underground, deadly and a great companion to any starting rebel."
ITEM.model = "models/weapons/c_kalash.mdl"
ITEM.class = "arccw_metrokalash"
ITEM.weaponCategory = "primary"
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}