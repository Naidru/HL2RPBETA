ITEM.name = "Combat Skillet"
ITEM.description = "Any sly remarks are sure to be met with a right thwack from this powerful weapon of war during your crusades, brother."
ITEM.model = "models/props_c17/metalPot002a.mdl"
ITEM.class = "weapon_hl2pan"
ITEM.weaponCategory = "melee"
ITEM.flag = "V"
ITEM.width = 2
ITEM.height = 3
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}