ITEM.name = "ABz-12g DShK"
ITEM.description = "Hacked and torn DShK made to fire shotgun shells, Crude as hell and feels like it'll explode any second, heavy, and painful to the arms."
ITEM.model = "models/weapons/c_abzats.mdl"
ITEM.class = "arccw_abzats"
ITEM.weaponCategory = "primary"
ITEM.flag = "V"
ITEM.width = 6
ITEM.height = 3
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}