ITEM.name = "Baretta M9"
ITEM.description = "An old US Government relic of old. Now it's just some tool with no name.."
ITEM.model = "models/weapons/arccw_go/v_pist_m9.mdl"
ITEM.class = "arccw_go_m9"
ITEM.weaponCategory = "sidearm"
ITEM.classes = {CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 2
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-17.581502914429, 250.7974395752, 0),
	fov	= 5.412494001838,
	pos	= Vector(57.109928131104, 181.7945098877, -60.738327026367)
}
