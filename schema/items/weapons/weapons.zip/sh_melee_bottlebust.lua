ITEM.name = "Busted Bottle"
ITEM.description = "The most classic of bar-combat instruments. You'd make a scottsman proud. This one's a bit sharper 'round them edges lad."
ITEM.model = "models/props_junk/garbage_glassbottle003a_chunk01.mdl"
ITEM.class = "weapon_hl2brokenbottle"
ITEM.weaponCategory = "melee"
ITEM.flag = "V"
ITEM.width = 1
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}