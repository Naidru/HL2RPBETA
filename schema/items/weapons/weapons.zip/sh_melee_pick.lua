ITEM.name = "Pickaxe"
ITEM.description = "Oh, honestly? Did you not read the colony policy? That defines you as company property? That waivers your say in autonomy?"
ITEM.model = "models/props_mining/pickaxe01.mdl"
ITEM.class = "weapon_hl2pickaxe"
ITEM.weaponCategory = "melee"
ITEM.flag = "V"
ITEM.width = 2
ITEM.height = 4
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}