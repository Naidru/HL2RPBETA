ITEM.name = "Empty Ration Pack"
ITEM.model = Model("models/foodnhouseholdaaaaa/combirationa.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "An unfilled Union Ration Pack. Workers will need to take this to their nearest distribution center after creation in order to have them filled with protein supplements for later distribution to the populace."
ITEM.category = "Industrial"
ITEM.permit = "consumables"