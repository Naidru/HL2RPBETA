ITEM.name = "Vortigaunt Special"
ITEM.model = Model("models/willardnetworks/food/xen_stew.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A soup made from Xenian origins. The Vortigaunts love it! Humans and Combine? Much less so. It won't kill you, but God is it horrible unless you're a many-eyed telepathic alien!"
ITEM.category = "Consumables"
ITEM.permit = "consumables"

ITEM.functions.Eat = {
    OnRun = function(itemTable)
        local client = itemTable.player

        client:SetHealth(math.min(client:Health() + 10, 100))

        return true
    end,
}