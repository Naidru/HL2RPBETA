ITEM.name = "Red Pill Bottle"
ITEM.model = Model("models/willardnetworks/skills/medjar3.mdl")
ITEM.description = "A small Red pill bottle, not sure what the colour means. Smells especially awful though."
ITEM.category = "Medical"
ITEM.price = 10

ITEM.functions.Apply = {
	sound = "CourragatedDawn/Xtra/C_24/Ambience/medkit_pickup.ogg",
	OnRun = function(itemTable)
		local client = itemTable.player
		local HP = client:Health()
		local MaxHP = client:GetMaxHealth()
		--client:RestoreStamina(100)
		client:SetHealth( math.Clamp( HP - 5, 0, MaxHP ) )
		return true
	end,
}
