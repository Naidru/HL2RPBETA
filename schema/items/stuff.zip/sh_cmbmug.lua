ITEM.name = "Union Coffee Mug"
ITEM.model = Model("models/bioshockinfinite/xoffee_mug_closed.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A Union-Branded Coffee Travel Mug. Civil Protection or Loyalist workers tend to get these to carry their ration drinks in."
ITEM.category = "Consumables"
ITEM.permit = "consumables"