ITEM.name = "Bank Soda - Zhongguo"
ITEM.RestoreHunger = 50
ITEM.model = "models/willardnetworks/food/bobdrinks_goodfella.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "An old brand of cola that fluttered around New York in it's prime. It survived the Seven Hour War and the Combine, but it's a rare treat."
ITEM.category = "Consumables"
ITEM.permit = "consumables"

ITEM.functions.Eat = {
    OnRun = function(itemTable)
        local client = itemTable.player

        client:SetHealth(math.min(client:Health() + 10, 100))

        return true
    end,
} 