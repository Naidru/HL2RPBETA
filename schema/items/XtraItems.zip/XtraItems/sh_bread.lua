ITEM.name = "Bread"
ITEM.RestoreHunger = 50
ITEM.model = "models/willardnetworks/food/bread_loaf.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "You've got to get that bread, even if it's now made of synthesized flour substitute."
ITEM.category = "Consumables"
ITEM.permit = "consumables"

ITEM.functions.Eat = {
    OnRun = function(itemTable)
        local client = itemTable.player

        client:SetHealth(math.min(client:Health() + 10, 100))

        return true
    end,
} 