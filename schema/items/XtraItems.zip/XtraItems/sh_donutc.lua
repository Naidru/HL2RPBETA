ITEM.name = "Lemon Creme Donut"
ITEM.RestoreHunger = 50
ITEM.model = "models/willardnetworks/food/creamtreat.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A donut filled with lemon cream. All synthesized of course, but it's the thought that counts."
ITEM.category = "Consumables"
ITEM.permit = "consumables"

ITEM.functions.Eat = {
    OnRun = function(itemTable)
        local client = itemTable.player

        client:SetHealth(math.min(client:Health() + 10, 100))

        return true
    end,
} 