ITEM.name = "White Egg"
ITEM.RestoreHunger = 50
ITEM.model = "models/willardnetworks/food/egg2.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "An egg. It cracks like a real egg, has yolk and whites, but nobody can tell if it's synthesized or not. This one is white."
ITEM.category = "Consumables"
ITEM.permit = "consumables"

ITEM.functions.Eat = {
    OnRun = function(itemTable)
        local client = itemTable.player

        client:SetHealth(math.min(client:Health() + 10, 100))

        return true
    end,
} 