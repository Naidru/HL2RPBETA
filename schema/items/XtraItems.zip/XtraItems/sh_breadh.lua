ITEM.name = "Bread Half"
ITEM.RestoreHunger = 50
ITEM.model = "models/willardnetworks/food/bread_half.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "Half a loaf of bread. Not as good as a full loaf, but it'll do."
ITEM.category = "Consumables"
ITEM.permit = "consumables"

ITEM.functions.Eat = {
    OnRun = function(itemTable)
        local client = itemTable.player

        client:SetHealth(math.min(client:Health() + 10, 100))

        return true
    end,
} 