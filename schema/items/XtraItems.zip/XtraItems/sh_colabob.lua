ITEM.name = "Radiobob Cola"
ITEM.RestoreHunger = 50
ITEM.model = "models/willardnetworks/food/bobdrinks_can.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "Cans from a mysterious sub-company called Radiobob. Ask and you won't find an answer. These cans somehow end up deposited into the cola machines, and not even the Union know who's doing it."
ITEM.category = "Consumables"
ITEM.permit = "consumables"

ITEM.functions.Eat = {
    OnRun = function(itemTable)
        local client = itemTable.player

        client:SetHealth(math.min(client:Health() + 10, 100))

        return true
    end,
} 