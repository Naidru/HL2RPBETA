ITEM.name = "Union Brand Cigarettes"
ITEM.RestoreHunger = 50
ITEM.model = "models/willardnetworks/cigarettes/cigarette_pack.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A pack of 20 Union Brand cigarettes. These ones taste like cool mint. Smoke 'em if you got 'em!"
ITEM.category = "Consumables"
ITEM.permit = "consumables"

ITEM.functions.Eat = {
    OnRun = function(itemTable)
        local client = itemTable.player

        client:SetHealth(math.min(client:Health() + 10, 100))

        return true
    end,
} 