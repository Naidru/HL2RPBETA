ITEM.name = "Cooked Fish"
ITEM.RestoreHunger = 50
ITEM.model = "models/willardnetworks/food/fishsteak.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "Conscripts and Rebels usually only get their hands on fish - and rarely at that. Some spawning pools or small schools managed to survive the onslaught of the Combine, and make for a delicious meal when located. This is the result of a chef's handiwork, and tastes amazing to boot!"
ITEM.category = "Consumables"
ITEM.permit = "consumables"

ITEM.functions.Eat = {
    OnRun = function(itemTable)
        local client = itemTable.player

        client:SetHealth(math.min(client:Health() + 10, 100))

        return true
    end,
} 