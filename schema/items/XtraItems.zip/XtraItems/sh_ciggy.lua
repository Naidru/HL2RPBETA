ITEM.name = "Cigarette"
ITEM.RestoreHunger = 50
ITEM.model = "models/willardnetworks/cigarettes/cigarette.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "Nobody's really sure if the 'tobacco' in the cigarettes are even real. It tastes and smokes just like the real thing."
ITEM.category = "Consumables"
ITEM.permit = "consumables"

ITEM.functions.Eat = {
    OnRun = function(itemTable)
        local client = itemTable.player

        client:SetHealth(math.min(client:Health() + 10, 100))

        return true
    end,
} 