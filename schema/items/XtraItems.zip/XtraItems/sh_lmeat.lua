ITEM.name = "Cooked Leech"
ITEM.RestoreHunger = 50
ITEM.model = "models/willardnetworks/food/cooked_leech.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A cooked leech. It's not the best food around, but it's meat and that counts for something. Just don't think about it when you eat it."
ITEM.category = "Consumables"
ITEM.permit = "consumables"

ITEM.functions.Eat = {
    OnRun = function(itemTable)
        local client = itemTable.player

        client:SetHealth(math.min(client:Health() + 10, 100))

        return true
    end,
} 