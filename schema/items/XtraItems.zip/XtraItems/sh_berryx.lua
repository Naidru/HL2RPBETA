ITEM.name = "Xen Berry"
ITEM.RestoreHunger = 50
ITEM.model = "models/willardnetworks/food/berries02.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "Strange, alien berries originating from Xen. These can be found in Xen infested zones, but are dangerous to acquire. Vortigaunts crave these as a snack."
ITEM.category = "Consumables"
ITEM.permit = "consumables"

ITEM.functions.Eat = {
    OnRun = function(itemTable)
        local client = itemTable.player

        client:SetHealth(math.min(client:Health() + 10, 100))

        return true
    end,
} 