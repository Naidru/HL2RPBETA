ITEM.name = "MEDIUM TIER Ration Coupon"
ITEM.model = Model("models/willardnetworks/props/rationcoupon2.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A slightly more valuable blue plastic ticket used in the trade of Combine goods and services. Wealth of 5."
ITEM.category = "Ration Coupon"
ITEM.permit = "consumables"