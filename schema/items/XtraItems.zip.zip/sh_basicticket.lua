ITEM.name = "BASIC TIER Ration Coupon"
ITEM.model = Model("models/willardnetworks/props/rationcoupon.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A simple red plastic ticket used in the trade of Combine goods and services. Wealth of 1."
ITEM.category = "Ration Coupon"
ITEM.permit = "consumables"