ITEM.name = "M9 Bayonet"
ITEM.description = "Standard steel knife, used by everyone and anyone, highly reliable and solid weapon."
ITEM.model = "models/weapons/arccw_go/v_knife_bayonet.mdl"
ITEM.class = "arccw_go_melee_knife"
ITEM.weaponCategory = "melee"
ITEM.flag = "v"
ITEM.width = 1
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.23955784738064, 270.44906616211, 0),
	fov	= 10.780103254469,
	pos	= Vector(0, 200, 0)
}
