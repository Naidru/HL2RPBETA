ITEM.name = "Glock 17"
ITEM.description = "A fast, semi-unreliable pistol that is known for it's square shape and fun switch."
ITEM.model = "models/weapons/arccw_go/v_pist_glock.mdl"
ITEM.class = "arccw_ud_glock"
ITEM.weaponCategory = "sidearm"
ITEM.flag = "V"
ITEM.width = 2
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}