ITEM.name = "Minimi M249-Paratrooper"
ITEM.description = "Worn and Torn LMG for light support and medium range engagements. Powerful if a bit heavy."
ITEM.model = "models/weapons/w_mach_m249para.mdl"
ITEM.class = "arccw_go_m249para"
ITEM.weaponCategory = "primary"
ITEM.flag = "V"
ITEM.width = 4
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}