ITEM.name = "MP5A4"
ITEM.description = "Used in Black Mesa by the HECU, Security and even the Black Ops for quite some time, a popular friend makes a reappearance."
ITEM.model = "models/weapons/arccw/c_ur_mp5.mdl"
ITEM.class = "arccw_ur_mp5"
ITEM.weaponCategory = "primary"
ITEM.flag = "V"
ITEM.width = 2
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}