ITEM.name = "Industrial Cleaning Solution"
ITEM.model = Model("models/willardnetworks/props/disinfectant.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A cyan coloured container of Union-Branded 'Coro-Quat' Cleaner, meant for disinfecting machinery and structures."
ITEM.category = "Industrial"
ITEM.permit = "consumables"