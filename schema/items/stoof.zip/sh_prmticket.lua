ITEM.name = "PREMIUM TIER Ration Coupon"
ITEM.model = Model("models/willardnetworks/props/rationcoupon3.mdl ")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "An EXTREMELY valuable white plastic ticket used in the trade of Combine goods and services. Wealth of 10. Don't let others know you have this!"
ITEM.category = "Ration Coupon"
ITEM.permit = "consumables"