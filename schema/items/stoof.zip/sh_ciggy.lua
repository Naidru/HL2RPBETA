ITEM.name = "Cigarette"
--ITEM.RestoreHunger = 50 -- no it shouldn't, don't eat the damn thing
ITEM.model = Model("models/willardnetworks/cigarettes/cigarette.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "Nobody's really sure if the 'tobacco' in the cigarettes are even real. It tastes and smokes just like the real thing."
ITEM.category = "Consumables"
ITEM.permit = "consumables"