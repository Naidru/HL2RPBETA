ITEM.name = "9mm Pistol Bullets"
ITEM.model = "models/items/357ammo.mdl"
ITEM.ammo = "pistol" -- type of the ammo
ITEM.ammoAmount = 30 -- amount of the ammo
ITEM.description = "A Box that contains %s of Pistol Ammo"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
