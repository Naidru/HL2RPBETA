ITEM.name = "SPAS-12"
ITEM.description = "A powerful pump-action shotgun."
ITEM.model = "models/weapons/w_shotgun.mdl"
ITEM.class = "arccw_ur_spas12"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EOW}
ITEM.width = 3
ITEM.height = 1
ITEM.iconCam = {
    pos = Vector(0, 200, 1),
    ang = Angle(0, 270, 0),
    fov = 10
}