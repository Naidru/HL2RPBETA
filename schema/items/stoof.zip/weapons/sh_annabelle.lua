ITEM.name = "Winchester Model 1886"
ITEM.description = "Ol' cowboy rifle, feel like a kid again with this blaster from the past. Expensive on ammo and illegal to own."
ITEM.model = "models/weapons/w_smg1.mdl"
ITEM.class = "arccw_hl_annabelle"
ITEM.weaponCategory = "primary"
ITEM.flag = "V"
ITEM.width = 4
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}