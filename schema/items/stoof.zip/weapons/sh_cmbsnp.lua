ITEM.name = "HS-90 Large Bore Rifle"
ITEM.description = "Powerful and dangerous sniper presumably made by either Steyr or some other company that was adopted by the US Military shortly before the portal storms, now used by the Conscripts and Overwatch primarily."
ITEM.model = "models/weapons/w_smg1.mdl"
ITEM.class = "arccw_hl_sniper"
ITEM.weaponCategory = "primary"
ITEM.flag = "V"
ITEM.width = 4
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}