ITEM.name = "H&K MP7 Conscript"
ITEM.description = "A compact, fully automatic sub-machine gun hacked haphazardly into a burst fire mode. It's surprisingly fun to use, though."
ITEM.model = "models/weapons/w_smg1.mdl"
ITEM.class = "arccw_hl_smg2"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}