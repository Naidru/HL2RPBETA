ITEM.name = "Remington Model 870"
ITEM.description = "Classic 1950's shotgun, often used by Conscripts in place of the Spas-12 due to it's decrease in weight. Feel like a detective eh?"
ITEM.model = "models/weapons/w_smg1.mdl"
ITEM.class = "arccw_ud_870"
ITEM.weaponCategory = "primary"
ITEM.flag = "V"
ITEM.width = 3
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}