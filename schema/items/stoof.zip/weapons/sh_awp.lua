ITEM.name = "PSG-90B Wasteland Warfare Magnum"
ITEM.description = "Powerful and dangerous Swedish sniper that was adopted by the US Military shortly before the portal storms, now used by the Conscripts primarily."
ITEM.model = "models/weapons/w_smg1.mdl"
ITEM.class = "arccw_ur_aw"
ITEM.weaponCategory = "primary"
ITEM.flag = "V"
ITEM.width = 4
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}