ITEM.name = "Consumables Permit"
ITEM.description = "A permit allowing you to sell consumable goods."
ITEM.permit = "consumables"