ITEM.name = "Unprinted Can"
ITEM.model = Model("models/props_nunk/popcan01a.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "An unmarked, unfilled can for Union Drinks. Workers will have to finish filling and printing these before taking them to the local distribution center for rationing."
ITEM.category = "Industrial"
ITEM.permit = "consumables"